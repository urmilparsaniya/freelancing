export interface RoleInterface {
  id: number;
  role: string;
  status: number;
  createdAt?: Date;
  updatedAt?: Date;
  deletedAt?: Date;
}
