export interface UserQualificationInterface {
  id: number;
  user_id: number;
  qualification_id: number;
  status: number;
  createdAt?: Date;
  updatedAt?: Date;
}
