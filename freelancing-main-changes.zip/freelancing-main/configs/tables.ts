export const TABLE_NAME = {
  USER: "tbl_user",
  QUALIFICATIONS: "tbl_qualifications",
  UNITS: "tbl_units",
  MAIN_OUTCOMES: "tbl_main_outcomes",
  OUTCOMES: "tbl_sub_outcomes",
  OUTCOME_SUBPOINTS: "tbl_outcome_subpoints",
  USER_QUALIFICATION: "tbl_user_qualification",
  ROLE: "tbl_role"
};
